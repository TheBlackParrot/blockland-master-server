//original script by Trinick

$autoEnableCustomMS = true;

package enableCustomMS {
	function postServerTCPObj::connect(%this, %addr) {
		parent::connect(%this, "your.hostnameorip.com:80");
		%this.cmd = strReplace(%this.cmd, "master2.blockland.us", "your.hostnameorip.com");
	}

	function queryMasterTCPObj::connect(%this, %addr) {
		parent::connect(%this, "your.hostnameorip.com:80");
		%this.cmd = strReplace(%this.cmd, "master2.blockland.us", "your.hostnameorip.com");
	}
};

function toggleCustomMS() {
	$customMSActive = !$customMSActive;
	if($customMSActive)
		activatePackage(enableCustomMS);
	else
		deactivatePackage(enableCustomMS);
}

if($autoEnableCustomMS) {
	activatePackage(enableCustomMS);
	$customMSActive = true;
}